import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useMobile } from "@/hooks/use-mobile";
import { 
  Search, 
  Heart, 
  ShoppingCart, 
  User, 
  Menu, 
  X,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function Header() {
  const isMobile = useMobile();
  const [location, setLocation] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileSearchVisible, setMobileSearchVisible] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navigationLinks = [
    { name: "Home", path: "/" },
    { name: "Shop", path: "/" },
    { name: "Products", path: "/products", active: true },
    { name: "Contact", path: "/" }
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-wrap items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <a 
              href="#" 
              className="text-2xl font-bold text-primary flex items-center"
              onClick={(e) => {
                e.preventDefault();
                setLocation("/");
              }}
            >
              <span className="bg-primary text-white rounded-full w-10 h-10 flex items-center justify-center mr-2">D</span>
              dealerz.
            </a>
          </div>

          {/* Search Bar - Hidden on mobile */}
          <div className="hidden md:flex items-center flex-1 max-w-xl mx-8">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search what you need"
                className="w-full py-2 pl-4 pr-10 rounded-md border border-gray-200 focus:outline-none focus:ring-primary focus:border-primary"
              />
              <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <Search className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Navigation Icons */}
          <div className="flex items-center space-x-6">
            {isMobile && (
              <button 
                className="text-gray-700 hover:text-primary" 
                onClick={() => setMobileSearchVisible(!mobileSearchVisible)}
              >
                <Search className="h-5 w-5" />
              </button>
            )}
            
            <button className="text-gray-700 hover:text-primary relative">
              <Heart className="h-5 w-5" />
              <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">3</span>
            </button>
            
            <button className="text-gray-700 hover:text-primary relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">1</span>
            </button>
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="text-gray-700 hover:text-primary flex items-center">
                    <User className="h-5 w-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem className="font-medium">
                    {user.username}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <button 
                className="text-gray-700 hover:text-primary"
                onClick={() => setLocation("/auth")}
              >
                <User className="h-5 w-5" />
              </button>
            )}
            
            {isMobile && (
              <Sheet>
                <SheetTrigger asChild>
                  <button className="text-gray-700 hover:text-primary md:hidden">
                    <Menu className="h-5 w-5" />
                  </button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col h-full">
                    <div className="flex justify-between items-center mb-8">
                      <span className="text-xl font-bold">Menu</span>
                      <SheetClose className="rounded-full hover:bg-gray-100 p-2">
                        <X className="h-4 w-4" />
                      </SheetClose>
                    </div>
                    <nav className="space-y-4">
                      {navigationLinks.map((link) => (
                        <a
                          key={link.name}
                          href={link.path}
                          className={`block py-2 px-4 rounded-md ${
                            link.active 
                              ? "text-primary font-medium" 
                              : "text-gray-700 hover:bg-gray-50"
                          }`}
                          onClick={(e) => {
                            e.preventDefault();
                            setLocation(link.path);
                          }}
                        >
                          {link.name}
                        </a>
                      ))}
                    </nav>
                  </div>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </div>

        {/* Mobile Search Bar (conditional) */}
        {isMobile && mobileSearchVisible && (
          <div className="mt-4 md:hidden">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search what you need"
                className="w-full py-2 pl-4 pr-10 rounded-md border border-gray-200 focus:outline-none focus:ring-primary focus:border-primary"
              />
              <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <Search className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* Main Navigation */}
        <nav className="hidden md:flex justify-center mt-4 pb-2">
          <div className="flex space-x-10">
            {navigationLinks.map((link) => (
              <a
                key={link.name}
                href={link.path}
                className={link.active ? "text-primary font-medium" : "text-gray-700 hover:text-primary"}
                onClick={(e) => {
                  e.preventDefault();
                  setLocation(link.path);
                }}
              >
                {link.name}
              </a>
            ))}
          </div>
        </nav>
      </div>
    </header>
  );
}
