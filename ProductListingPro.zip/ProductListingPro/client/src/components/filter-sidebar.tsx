import { useState, useEffect } from "react";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

type CategoryType = "all" | "electronics" | "jewelery" | "men's clothing" | "women's clothing";
type PriceRange = [number, number];

interface FilterSidebarProps {
  onApplyFilters: (category: CategoryType, priceRange: PriceRange) => void;
  selectedCategory: CategoryType;
  selectedPriceRange: PriceRange;
  isMobile?: boolean;
}

export default function FilterSidebar({
  onApplyFilters,
  selectedCategory,
  selectedPriceRange,
  isMobile = false
}: FilterSidebarProps) {
  const [category, setCategory] = useState<CategoryType>(selectedCategory);
  const [priceRange, setPriceRange] = useState<PriceRange>(selectedPriceRange);
  const [minPrice, setMinPrice] = useState<string>(selectedPriceRange[0].toString());
  const [maxPrice, setMaxPrice] = useState<string>(selectedPriceRange[1].toString());

  // Update local state when props change
  useEffect(() => {
    setCategory(selectedCategory);
    setPriceRange(selectedPriceRange);
    setMinPrice(selectedPriceRange[0].toString());
    setMaxPrice(selectedPriceRange[1].toString());
  }, [selectedCategory, selectedPriceRange]);

  // Handle slider change
  const handleSliderChange = (value: number[]) => {
    const newRange: PriceRange = [value[0], value[1]];
    setPriceRange(newRange);
    setMinPrice(newRange[0].toString());
    setMaxPrice(newRange[1].toString());
  };

  // Handle min/max input changes
  const handleMinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setMinPrice(value);
    // Only update slider if value is a valid number and not empty
    if (value !== "" && !isNaN(Number(value))) {
      const numValue = Number(value);
      // Ensure min doesn't exceed max
      if (numValue <= priceRange[1]) {
        setPriceRange([numValue, priceRange[1]]);
      }
    }
  };

  const handleMaxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setMaxPrice(value);
    // Only update slider if value is a valid number and not empty
    if (value !== "" && !isNaN(Number(value))) {
      const numValue = Number(value);
      // Ensure max isn't less than min
      if (numValue >= priceRange[0]) {
        setPriceRange([priceRange[0], numValue]);
      }
    }
  };

  // Apply all filters
  const applyFilters = () => {
    // Parse and validate min/max price
    const min = parseInt(minPrice) || 0;
    const max = parseInt(maxPrice) || 1000;
    // Ensure min doesn't exceed max
    const validatedPriceRange: PriceRange = [
      Math.min(min, max),
      Math.max(min, max)
    ];
    
    onApplyFilters(category, validatedPriceRange);
  };

  // Categories for the filter
  const categories = [
    { id: "all", label: "All Categories", value: "all" as CategoryType },
    { id: "electronics", label: "Electronics", value: "electronics" as CategoryType },
    { id: "jewelery", label: "Jewelry", value: "jewelery" as CategoryType },
    { id: "men", label: "Men's Clothing", value: "men's clothing" as CategoryType },
    { id: "women", label: "Women's Clothing", value: "women's clothing" as CategoryType },
  ];

  return (
    <div className={`bg-white rounded-lg p-6 ${!isMobile && "sticky top-32"}`}>
      <h2 className="text-xl font-bold mb-6">Categories</h2>
      
      <Accordion type="multiple" defaultValue={["categories", "price", "colors", "size"]}>
        {/* Categories Section */}
        <AccordionItem value="categories">
          <AccordionTrigger>All Categories</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-3 pl-2">
              {categories.map((cat) => (
                <div key={cat.id} className="flex items-center">
                  <Checkbox
                    id={`cat-${cat.id}`}
                    checked={category === cat.value}
                    onCheckedChange={() => setCategory(cat.value)}
                    className="mr-3 h-4 w-4 rounded-sm data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                  />
                  <Label
                    htmlFor={`cat-${cat.id}`}
                    className="text-gray-600 cursor-pointer"
                  >
                    {cat.label}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Price Range Section */}
        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="pl-2">
              <div className="mb-4">
                <Slider
                  value={[priceRange[0], priceRange[1]]}
                  min={0}
                  max={1000}
                  step={10}
                  onValueChange={handleSliderChange}
                  className="my-6"
                />
                <div className="flex justify-between mt-2 text-sm text-gray-500">
                  <span>$0</span>
                  <span>$1000</span>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="relative flex-1">
                  <Input
                    type="number"
                    min={0}
                    max={1000}
                    value={minPrice}
                    onChange={handleMinChange}
                    className="w-full p-2 pl-7 border border-gray-200 rounded-md"
                  />
                  <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
                </div>
                <span className="text-gray-400">-</span>
                <div className="relative flex-1">
                  <Input
                    type="number"
                    min={0}
                    max={1000}
                    value={maxPrice}
                    onChange={handleMaxChange}
                    className="w-full p-2 pl-7 border border-gray-200 rounded-md"
                  />
                  <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Colors Section */}
        <AccordionItem value="colors">
          <AccordionTrigger>Colors</AccordionTrigger>
          <AccordionContent>
            <div className="pl-2">
              <div className="flex flex-wrap gap-3">
                <div className="h-8 w-8 rounded-full bg-blue-500 cursor-pointer border-2 border-white hover:border-gray-300"></div>
                <div className="h-8 w-8 rounded-full bg-green-500 cursor-pointer border-2 border-white hover:border-gray-300"></div>
                <div className="h-8 w-8 rounded-full bg-red-500 cursor-pointer border-2 border-white hover:border-gray-300"></div>
                <div className="h-8 w-8 rounded-full bg-yellow-500 cursor-pointer border-2 border-white hover:border-gray-300"></div>
                <div className="h-8 w-8 rounded-full bg-purple-500 cursor-pointer border-2 border-white hover:border-gray-300"></div>
                <div className="h-8 w-8 rounded-full bg-gray-800 cursor-pointer border-2 border-white hover:border-gray-300"></div>
                <div className="h-8 w-8 rounded-full bg-pink-500 cursor-pointer border-2 border-white hover:border-gray-300"></div>
                <div className="h-8 w-8 rounded-full bg-indigo-500 cursor-pointer border-2 border-white hover:border-gray-300"></div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Size Section */}
        <AccordionItem value="size">
          <AccordionTrigger>Size</AccordionTrigger>
          <AccordionContent>
            <div className="pl-2">
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" className="h-10 w-10 rounded-md">XS</Button>
                <Button variant="outline" size="sm" className="h-10 w-10 rounded-md">S</Button>
                <Button variant="outline" size="sm" className="h-10 w-10 rounded-md border-primary text-primary">M</Button>
                <Button variant="outline" size="sm" className="h-10 w-10 rounded-md">L</Button>
                <Button variant="outline" size="sm" className="h-10 w-10 rounded-md">XL</Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Apply Filters Button */}
      <Button 
        onClick={applyFilters}
        className="w-full bg-primary hover:bg-primary/90 text-white mt-6"
      >
        Apply Filter
      </Button>
    </div>
  );
}
