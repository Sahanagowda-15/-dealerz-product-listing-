import ProductCard from "./product-card";

interface Product {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  rating: {
    rate: number;
    count: number;
  };
}

interface ProductGridProps {
  products: Product[];
}

export default function ProductGrid({ products }: ProductGridProps) {
  // Create a function to determine if a product should show as "new"
  // For this demo, we'll mark products with id divisible by 5 as new
  const isProductNew = (id: number) => id % 5 === 0;
  
  // Create a function to determine if a product has a discount
  // For this demo, we'll apply discounts to products with id divisible by 3
  const getProductDiscount = (id: number) => (id % 3 === 0 ? 15 + (id % 4) * 5 : undefined);
  
  // Calculate old price based on discount
  const getOldPrice = (price: number, discount?: number) => {
    if (!discount) return undefined;
    return parseFloat((price / (1 - discount / 100)).toFixed(2));
  };

  return (
    <div className="product-grid">
      {products.map((product) => {
        const discount = getProductDiscount(product.id);
        const isNew = isProductNew(product.id);
        const oldPrice = getOldPrice(product.price, discount);
        
        return (
          <ProductCard
            key={product.id}
            id={product.id}
            title={product.title}
            price={product.price}
            oldPrice={oldPrice}
            image={product.image}
            rating={product.rating}
            category={product.category}
            isNew={isNew}
            discount={discount}
          />
        );
      })}
    </div>
  );
}
