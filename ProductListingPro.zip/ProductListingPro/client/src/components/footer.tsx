import { Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-gray-100 py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-6">
              <a href="/" className="text-2xl font-bold text-primary flex items-center">
                <span className="bg-primary text-white rounded-full w-10 h-10 flex items-center justify-center mr-2">D</span>
                dealerz.
              </a>
            </div>
            <p className="text-gray-600 mb-6">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo in vestibulum, sed dapibus tristique nullam.
            </p>
            <div className="flex space-x-4">
              <Button variant="outline" size="icon" className="rounded-full hover:bg-primary hover:text-white">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full hover:bg-primary hover:text-white">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full hover:bg-primary hover:text-white">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full hover:bg-primary hover:text-white">
                <Linkedin className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-6">Get in Touch with Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="w-4 h-4 mt-1 mr-3 text-primary" />
                <span className="text-gray-600">123 Fashion Street, Los Angeles, CA 90012</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-3 text-primary" />
                <span className="text-gray-600">+1 234 5678 900</span>
              </li>
              <li className="flex items-center">
                <Mail className="w-4 h-4 mr-3 text-primary" />
                <span className="text-gray-600">support@dealerz.com</span>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-lg font-bold mb-6">Shop Categories</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-600 hover:text-primary">Men</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">Women</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">Kids</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">Accessories</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">New Arrivals</a></li>
            </ul>
          </div>

          {/* Information */}
          <div>
            <h3 className="text-lg font-bold mb-6">Information</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-600 hover:text-primary">About Us</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">Contact Us</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">Terms & Conditions</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">Shipping & Returns</a></li>
              <li><a href="#" className="text-gray-600 hover:text-primary">Privacy Policy</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-12 pt-8 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Dealerz. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
}
