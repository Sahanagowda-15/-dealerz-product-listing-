import { useState } from "react";
import { Heart, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ProductCardProps {
  id: number;
  title: string;
  price: number;
  oldPrice?: number;
  image: string;
  rating: {
    rate: number;
    count: number;
  };
  isNew?: boolean;
  discount?: number;
  category: string;
}

export default function ProductCard({
  id,
  title,
  price,
  oldPrice,
  image,
  rating,
  isNew = false,
  discount,
  category
}: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Show full stars based on rating
  const renderStars = () => {
    const stars = [];
    const fullStars = Math.floor(rating.rate);
    const hasHalfStar = rating.rate % 1 >= 0.5;

    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <svg key={`star-${i}`} xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      );
    }

    // Add half star if needed
    if (hasHalfStar) {
      stars.push(
        <svg key="half-star" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400" viewBox="0 0 20 20">
          <defs>
            <linearGradient id="half-fill" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="50%" stopColor="#FACC15" />
              <stop offset="50%" stopColor="#D1D5DB" />
            </linearGradient>
          </defs>
          <path fill="url(#half-fill)" d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      );
    }

    // Add empty stars to make total of 5
    for (let i = fullStars + (hasHalfStar ? 1 : 0); i < 5; i++) {
      stars.push(
        <svg key={`empty-${i}`} xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-300 fill-current" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      );
    }

    return stars;
  };

  return (
    <div 
      className="product-card" 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative group">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-80 object-contain bg-gray-50 rounded-lg p-4" 
        />
        
        {/* Hover overlay with buttons */}
        <div className={`absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-opacity flex items-center justify-center ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <Button variant="outline" size="icon" className="bg-white hover:bg-primary hover:text-white mr-2 h-10 w-10 rounded-full">
            <Heart className="h-5 w-5" />
          </Button>
          <Button variant="outline" size="icon" className="bg-white hover:bg-primary hover:text-white h-10 w-10 rounded-full">
            <ShoppingCart className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Labels (discount or new) */}
        {(discount || isNew) && (
          <div className="absolute top-3 left-3">
            {discount ? (
              <Badge className="bg-primary text-white text-xs font-normal hover:bg-primary">-{discount}%</Badge>
            ) : isNew ? (
              <Badge className="bg-primary text-white text-xs font-normal hover:bg-primary">New</Badge>
            ) : null}
          </div>
        )}
      </div>
      
      <div className="pt-4">
        <h3 className="font-medium text-lg mb-1 hover:text-primary cursor-pointer truncate">{title}</h3>
        <div className="flex items-center mb-1">
          <div className="flex">
            {renderStars()}
          </div>
          <span className="text-xs text-gray-500 ml-1">({rating.count} reviews)</span>
        </div>
        <div className="flex items-center">
          <span className="text-primary font-bold">${price.toFixed(2)}</span>
          {oldPrice && (
            <span className="text-gray-400 line-through text-sm ml-2">${oldPrice.toFixed(2)}</span>
          )}
        </div>
      </div>
    </div>
  );
}
