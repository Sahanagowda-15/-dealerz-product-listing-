import { useLocation } from "wouter";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  const [, setLocation] = useLocation();

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <div className="text-center max-w-2xl mx-auto">
          <h1 className="text-4xl font-bold mb-6">Welcome to Dealerz</h1>
          <p className="text-lg text-gray-600 mb-8">
            Discover our amazing products and best deals
          </p>
          <Button 
            size="lg" 
            className="bg-primary hover:bg-primary/90 text-white"
            onClick={() => setLocation("/products")}
          >
            Shop Now
          </Button>
        </div>
      </main>
      <Footer />
    </div>
  );
}
