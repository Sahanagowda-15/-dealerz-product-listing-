import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import Footer from "@/components/footer";
import FilterSidebar from "@/components/filter-sidebar";
import ProductGrid from "@/components/product-grid";
import { Loader2, Filter, ChevronLeft, ChevronRight } from "lucide-react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useMobile } from "@/hooks/use-mobile";

// Define filters and sorting types
type SortType = "default" | "price-asc" | "price-desc" | "rating";
type CategoryType = "all" | "electronics" | "jewelery" | "men's clothing" | "women's clothing";
type PriceRange = [number, number];

// Product type from FakeStoreAPI
interface Product {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  rating: {
    rate: number;
    count: number;
  };
}

export default function ProductsPage() {
  const isMobile = useMobile();
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState("9");
  const [sort, setSort] = useState<SortType>("default");
  const [categoryFilter, setCategoryFilter] = useState<CategoryType>("all");
  const [priceRange, setPriceRange] = useState<PriceRange>([0, 1000]);

  // Fetch products from FakeStoreAPI
  const { data: products, isLoading, error } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const response = await fetch("https://fakestoreapi.com/products");
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      return response.json();
    },
  });

  // Apply filters and sorting
  const filteredProducts = products ? products
    .filter(product => categoryFilter === "all" || product.category === categoryFilter)
    .filter(product => product.price >= priceRange[0] && product.price <= priceRange[1])
    .sort((a, b) => {
      if (sort === "price-asc") return a.price - b.price;
      if (sort === "price-desc") return b.price - a.price;
      if (sort === "rating") return b.rating.rate - a.rating.rate;
      return 0; // Default, no sorting
    }) : [];

  // Pagination
  const totalProducts = filteredProducts?.length || 0;
  const totalPages = Math.ceil(totalProducts / parseInt(itemsPerPage));
  const currentProducts = filteredProducts.slice(
    (currentPage - 1) * parseInt(itemsPerPage),
    currentPage * parseInt(itemsPerPage)
  );

  // Handle page changes
  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
    window.scrollTo(0, 0);
  };

  // Apply all filters
  const applyFilters = (category: CategoryType, price: PriceRange) => {
    setCategoryFilter(category);
    setPriceRange(price);
    setCurrentPage(1);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      {/* Page Header */}
      <div className="bg-[#F4F7F8] py-12 md:py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Our Products</h1>
          <p className="text-gray-500">Home / Shop</p>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar for desktop */}
          <div className="lg:w-1/4 hidden lg:block">
            <FilterSidebar 
              onApplyFilters={applyFilters} 
              selectedCategory={categoryFilter}
              selectedPriceRange={priceRange}
            />
          </div>

          {/* Mobile filter sheet */}
          <Sheet>
            <div className="lg:hidden mb-4">
              <SheetTrigger asChild>
                <Button variant="outline" className="flex items-center">
                  <Filter className="h-4 w-4 mr-2" />
                  <span>Filters</span>
                </Button>
              </SheetTrigger>
            </div>
            <SheetContent side="left" className="w-[300px] sm:w-[400px]">
              <FilterSidebar 
                onApplyFilters={applyFilters} 
                selectedCategory={categoryFilter}
                selectedPriceRange={priceRange}
                isMobile={true}
              />
            </SheetContent>
          </Sheet>

          {/* Product Content */}
          <div className="lg:w-3/4">
            {/* Controls */}
            <div className="mb-6 flex flex-col md:flex-row md:justify-between md:items-center">
              <div className="flex items-center justify-between w-full mb-4 md:mb-0 md:w-auto">
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 mr-2">Show:</span>
                  <Select
                    value={itemsPerPage}
                    onValueChange={(value) => {
                      setItemsPerPage(value);
                      setCurrentPage(1);
                    }}
                  >
                    <SelectTrigger className="w-20">
                      <SelectValue placeholder="9" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="9">9</SelectItem>
                      <SelectItem value="12">12</SelectItem>
                      <SelectItem value="24">24</SelectItem>
                      <SelectItem value="1000">All</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex items-center justify-between w-full md:w-auto">
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 mr-2">Sort by:</span>
                  <Select
                    value={sort}
                    onValueChange={(value) => setSort(value as SortType)}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Most Popular" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="default">Most Popular</SelectItem>
                      <SelectItem value="price-asc">Price: Low to High</SelectItem>
                      <SelectItem value="price-desc">Price: High to Low</SelectItem>
                      <SelectItem value="rating">Highest Rated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Loading state */}
            {isLoading && (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            )}

            {/* Error state */}
            {error && (
              <div className="text-center py-12">
                <p className="text-destructive text-lg">Failed to load products</p>
                <p className="text-gray-500">Please try again later</p>
              </div>
            )}

            {/* Empty state */}
            {!isLoading && filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-lg mb-4">No products found</p>
                <p className="text-gray-500 mb-6">Try adjusting your filters</p>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setCategoryFilter("all");
                    setPriceRange([0, 1000]);
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            )}

            {/* Products grid */}
            {!isLoading && filteredProducts.length > 0 && (
              <ProductGrid products={currentProducts} />
            )}

            {/* Pagination */}
            {!isLoading && filteredProducts.length > 0 && totalPages > 1 && (
              <div className="mt-12 flex justify-center">
                <div className="flex space-x-1">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>

                  {Array.from({ length: totalPages }).map((_, index) => {
                    const page = index + 1;
                    // Show first, last, current, and pages around current
                    if (
                      page === 1 ||
                      page === totalPages ||
                      (page >= currentPage - 1 && page <= currentPage + 1)
                    ) {
                      return (
                        <Button
                          key={page}
                          variant={currentPage === page ? "default" : "outline"}
                          className={currentPage === page ? "bg-primary text-white" : ""}
                          onClick={() => goToPage(page)}
                        >
                          {page}
                        </Button>
                      );
                    } else if (
                      (page === currentPage - 2 && currentPage > 3) ||
                      (page === currentPage + 2 && currentPage < totalPages - 2)
                    ) {
                      return (
                        <Button key={page} variant="outline" disabled>
                          ...
                        </Button>
                      );
                    }
                    return null;
                  })}

                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
