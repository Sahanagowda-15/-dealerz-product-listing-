import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    console.log("Seeding database...");

    // Check if users already exist
    const existingUsers = await db.select().from(schema.users);
    
    // Only seed if no users exist
    if (existingUsers.length === 0) {
      console.log("Creating default users...");
      
      // Create a demo user
      await db.insert(schema.users).values([
        {
          username: "demo",
          // This is the hashed version of "password" - in production, you would hash this properly
          password: "5a83109005c12e977ebb1fafc8e6abdf0cdeb7f0a4c1a52198d3b6c40975146ad219bca8f2038a1b2c9e5cee61566d27ab91dc018db0d95ef1cb3ca3a3a2c9ad.57e77bd75b40ed89",
        },
        {
          username: "admin",
          // This is the hashed version of "admin123" - in production, you would hash this properly
          password: "61eaef3d4a97c8cc9bd4f3c7204befadc61c13a5223bbddf89416a79c03c4be93cbc5784c4a5d75cf42c6d5c91195c0ef10d29b381e6da8316c11e723e46bc33.9d5023a2dceb85dd",
        },
      ]);
      
      console.log("Default users created.");
    } else {
      console.log("Users already exist, skipping seed.");
    }

    console.log("Seeding completed successfully.");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
