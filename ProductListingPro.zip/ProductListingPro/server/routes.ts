import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import axios from "axios";

export async function registerRoutes(app: Express): Promise<Server> {
  // Sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Define a route to fetch products from FakeStoreAPI
  app.get("/api/products", async (req, res) => {
    try {
      const response = await axios.get("https://fakestoreapi.com/products");
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Define a route to fetch a specific product from FakeStoreAPI
  app.get("/api/products/:id", async (req, res) => {
    try {
      const productId = req.params.id;
      const response = await axios.get(`https://fakestoreapi.com/products/${productId}`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Define a route to fetch product categories from FakeStoreAPI
  app.get("/api/categories", async (req, res) => {
    try {
      const response = await axios.get("https://fakestoreapi.com/products/categories");
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  // Define a route to fetch products by category from FakeStoreAPI
  app.get("/api/categories/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const response = await axios.get(`https://fakestoreapi.com/products/category/${category}`);
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching products by category:", error);
      res.status(500).json({ error: "Failed to fetch products by category" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
