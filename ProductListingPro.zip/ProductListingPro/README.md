# Dealerz - Product Listing Page

A responsive Product Listing Page built with React.js and SSR, integrated with FakeStoreAPI and user authentication.

## Features

- User authentication (login/signup)
- Product listing with filtering capabilities
- Responsive design for desktop, tablet, and mobile
- Server-side rendering for improved SEO
- Database integration with PostgreSQL

## Technology Stack

- **Frontend**: React.js, TailwindCSS, shadcn/ui components
- **Backend**: Express.js, PostgreSQL
- **ORM**: Drizzle
- **Authentication**: Passport.js
- **Data Fetching**: TanStack Query (React Query)
- **Routing**: wouter

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- PostgreSQL database

### Installation

1. Clone the repository
   ```
   git clone https://github.com/yourusername/dealerz-product-listing.git
   cd dealerz-product-listing
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Set up environment variables
   Create a `.env` file in the root directory with the following:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/dbname
   SESSION_SECRET=your_secret_key
   ```

4. Initialize the database
   ```
   npm run db:push
   npm run db:seed
   ```

5. Start the development server
   ```
   npm run dev
   ```

6. Open your browser and navigate to `http://localhost:5000`

## Demo Credentials

- Username: demo
- Password: password

## Contact

- Email: sahanasm1507@gmail.com
- Phone: 7795049087